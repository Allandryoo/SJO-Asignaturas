const contador = document.querySelector('#count');
const clickBtn = document.querySelector('#click-btn');
const lvlUpBtn = document.querySelector('#lvlup-btn');
const lvlUpBtnPlus = document.querySelector('#lvlup-btn-plus');
const resetBtn = document.querySelector('#reset-btn');

let count = 0;
let multi = 1;

clickBtn.addEventListener("click", () => {
    count += multi;
    contador.textContent = count;
    if (count >= 10000) {
        clickBtn.style.display = "none";
        lvlUpBtn.style.display = "none";
        lvlUpBtnPlus.style.display = "none";
        contador.textContent = "¡Felicidades! Has llegado al máximo.";
        resetBtn.style.display = "block";
    }
});

resetBtn.addEventListener("click", () => {
    count = 0;
    multi = 100;
    contador.textContent = count;
    clickBtn.style.display = "block";
    lvlUpBtn.style.display = "block";
    lvlUpBtnPlus.style.display = "block";
    resetBtn.style.display = "none";
});

lvlUpBtn.addEventListener("click", () => {
    if (count >= 200) {
        count -= 200;
        multi *= 2;
        contador.textContent = count;
    }
});

lvlUpBtnPlus.addEventListener("click", () => {
    if (count >= 1000) {
        count -= 1000;
        multi *= 4;
        contador.textContent = count;
    }
});